import { Component, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { PdfViewerModule } from 'ng2-pdf-viewer';

@Component({
    selector: 'app-pdf-signing',
    standalone: true,
    imports: [CommonModule, FormsModule, PdfViewerModule],
    templateUrl: './pdf-signing.component.html',
    styleUrl: './pdf-signing.component.scss'
})
export class PdfSigningComponent implements AfterViewInit {
    @ViewChild('signatureCanvas') signatureCanvas!: ElementRef<HTMLCanvasElement>;
    @ViewChild('pdfContainer') pdfContainer!: ElementRef<HTMLDivElement>;

    documentTitle: string = '';
    pdfUrl: string = '/assets/pdf/fw9.pdf';

    // Signature states
    isDrawing = false;
    typedSignature = '';
    signatureFile: File | null = null;
    signatureFileUrl: string | null = null;
    signatureScale: number = 1;

    // Placed signature
    placedSignature: {
        type: 'drawn' | 'typed' | 'uploaded';
        data: string;
        x: number;
        y: number;
        width: number;
        height: number;
        baseWidth: number;
        baseHeight: number;
        isDragging: boolean;
        isResizing: boolean;
        isFixed: boolean;
    } | null = null;

    private ctx: CanvasRenderingContext2D | null = null;
    private lastX = 0;
    private lastY = 0;

    constructor(
        private router: Router,
        private route: ActivatedRoute
    ) {
        // Get document title from route params
        this.route.queryParams.subscribe(params => {
            this.documentTitle = params['title'] || 'Document';
        });
    }

    ngAfterViewInit() {
        if (this.signatureCanvas) {
            this.ctx = this.signatureCanvas.nativeElement.getContext('2d');
            if (this.ctx) {
                this.ctx.strokeStyle = '#000';
                this.ctx.lineWidth = 2;
                this.ctx.lineCap = 'round';
            }
        }
    }

    // Drawing signature methods
    startDrawing(event: MouseEvent) {
        this.isDrawing = true;
        const rect = this.signatureCanvas.nativeElement.getBoundingClientRect();
        this.lastX = event.clientX - rect.left;
        this.lastY = event.clientY - rect.top;
    }

    draw(event: MouseEvent) {
        if (!this.isDrawing || !this.ctx) return;

        const rect = this.signatureCanvas.nativeElement.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;

        this.ctx.beginPath();
        this.ctx.moveTo(this.lastX, this.lastY);
        this.ctx.lineTo(x, y);
        this.ctx.stroke();

        this.lastX = x;
        this.lastY = y;
    }

    stopDrawing() {
        this.isDrawing = false;
    }

    clearSignature() {
        if (this.ctx) {
            this.ctx.clearRect(0, 0, this.signatureCanvas.nativeElement.width, this.signatureCanvas.nativeElement.height);
        }
    }

    useDrawnSignature() {
        const canvas = this.signatureCanvas.nativeElement;
        const dataUrl = canvas.toDataURL();
        this.placeSignatureOnPdf('drawn', dataUrl);
    }

    // Typed signature methods
    useTypedSignature() {
        if (!this.typedSignature.trim()) {
            alert('Please type your signature first');
            return;
        }
        this.placeSignatureOnPdf('typed', this.typedSignature);
    }

    // File upload methods
    onFileSelected(event: Event) {
        const input = event.target as HTMLInputElement;
        if (input.files && input.files[0]) {
            this.signatureFile = input.files[0];
            const reader = new FileReader();
            reader.onload = (e) => {
                this.signatureFileUrl = e.target?.result as string;
                this.placeSignatureOnPdf('uploaded', this.signatureFileUrl);
            };
            reader.readAsDataURL(this.signatureFile);
        }
    }

    // Place signature on PDF
    placeSignatureOnPdf(type: 'drawn' | 'typed' | 'uploaded', data: string) {
        this.signatureScale = 1;
        const baseWidth = 200;
        const baseHeight = 60;

        this.placedSignature = {
            type,
            data,
            x: 100,
            y: 200,
            width: baseWidth,
            height: baseHeight,
            baseWidth: baseWidth,
            baseHeight: baseHeight,
            isDragging: false,
            isResizing: false,
            isFixed: false
        };
    }

    onScaleChange(event: Event) {
        const input = event.target as HTMLInputElement;
        this.signatureScale = parseFloat(input.value);
        if (this.placedSignature) {
            this.placedSignature.width = this.placedSignature.baseWidth * this.signatureScale;
            this.placedSignature.height = this.placedSignature.baseHeight * this.signatureScale;
        }
    }

    // Signature manipulation on PDF
    onSignatureMouseDown(event: MouseEvent) {
        if (!this.placedSignature || this.placedSignature.isFixed) return;

        this.placedSignature.isDragging = true;
        event.preventDefault();
    }

    onPdfMouseMove(event: MouseEvent) {
        if (!this.placedSignature || !this.placedSignature.isDragging) return;

        const rect = this.pdfContainer.nativeElement.getBoundingClientRect();
        this.placedSignature.x = event.clientX - rect.left - this.placedSignature.width / 2;
        this.placedSignature.y = event.clientY - rect.top - this.placedSignature.height / 2;
    }

    onPdfMouseUp() {
        if (this.placedSignature) {
            this.placedSignature.isDragging = false;
        }
    }

    fixSignature() {
        if (this.placedSignature) {
            this.placedSignature.isFixed = true;
            alert('Signature placed successfully!');
        }
    }

    cancelPlacement() {
        this.placedSignature = null;
    }

    // Upload final PDF
    uploadSignedPdf() {
        if (!this.placedSignature || !this.placedSignature.isFixed) {
            alert('Please place and fix the signature first');
            return;
        }

        // TODO: Implement actual PDF upload with signature
        console.log('Uploading signed PDF...');
        alert('PDF signed and uploaded successfully!');
        this.goBack(true);
    }

    goBack(signed: boolean = false) {
        this.router.navigate(['/wizard/step-5'], {
            queryParams: signed ? { signed: 'true' } : {},
            skipLocationChange: true
        });
    }
}
